

$(function(){
	$("#gestionarProyecto").click(function({
		$("#content").load("nuevoProyecto.html");
	});
});